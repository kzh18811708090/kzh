# -*- coding: utf-8 -*-
"""
Created on Tue May  1 08:01:11 2018

@author: Administrator
"""
from wordcloud import WordCloud,ImageColorGenerator
import sys

import time
import numpy as np
from sklearn.cluster import KMeans
import pandas as pd
import matplotlib.pyplot as plt
from snownlp import SnowNLP
import os
import pyprind  
bar = pyprind.ProgBar(30,monitor=True,title="profiling")  

time_status_list_total=dict()
sentiments_status_total=dict()
time_total=[]

content_list_total=[]


for info in os.listdir(r'E:\python learning\data2'):
    domain = os.path.abspath(r'E:\python learning\data2') #获取文件夹的路径，此处其实没必要这么写，目的是为了熟悉os的文件夹操作
    info = os.path.join(domain,info) #将路径与文件名结合起来就是每个文件的完整路径
    data1=pd.read_csv(info)
    time_list=data1[['time']]
    #获取时间str，并转化为float
    time_real=[]
    for i in range(0,len(time_list)):
        timeArray = time.strptime(data1.xs('time',axis=1)[i], "%Y-%m-%d %H:%M")
        time_real.append(timeArray[3]+timeArray[4]/60)
        time_total.append(timeArray[3]+timeArray[4]/60)
    #对时间进行聚类，k均值，分四类
    time_real=np.array(time_real).reshape(-1,1)
    
    estimator = KMeans(n_clusters=4)#构造聚类器
    estimator.fit(time_real)#聚类
    label_pred = estimator.labels_ #获取聚类标签
    centroids = estimator.cluster_centers_ #获取聚类中心
    inertia = estimator.inertia_ # 获取聚类准则的总和
    
    #写一个对微博原文list进行情感分析的函数
    def snowanalysis(textlist):
        sentimentslist = []
        for li in textlist:
            s = SnowNLP(li)
            #print(li)
            #print(s.sentiments)
            sentimentslist.append(s.sentiments)
        return sentimentslist
    #获取微博原文并清除NaN（float类型，不是str）
    content_list=[]
    for i in range(len(data1)):
        content_list.append(data1.xs('content',axis=1)[i])
    
    content_list = [x for x in content_list if (type(x)==str)]
    content_list_total=content_list_total+content_list
    sentiments_1=snowanalysis(content_list)
    #单条微博和整个用户的情感判断方法
    sentimentscounts_pos=0
    sentimentscounts_neg=0
    for i in range(len(sentiments_1)):
        if sentiments_1[i-1]>0.6:
            sentimentscounts_pos=sentimentscounts_pos+1
        if sentiments_1[i-1]<0.4:
            sentimentscounts_neg=sentimentscounts_neg+1
            
    if (sentimentscounts_pos-sentimentscounts_neg)>=(0.2*len(sentiments_1)):
        sentimentsstatus="positive"
    
    if (sentimentscounts_pos-sentimentscounts_neg)<=-(0.2*len(sentiments_1)):
        sentimentsstatus="negative" 
        
    if -(0.2*len(sentiments_1))<(sentimentscounts_pos-sentimentscounts_neg)<(0.2*len(sentiments_1)):
        sentimentsstatus="normal" 
    if (sentimentscounts_pos>(0.3*len(sentiments_1)) and sentimentscounts_neg>(0.3*len(sentiments_1))):
        sentimentsstatus="hard to say" 
    
    centroids_list=centroids.flatten()
    centroids_list.sort()
    #根据时间聚类定性分析活跃时间
    time_status_list=[]
    for i in range(len(centroids_list)):
        if (centroids_list[i]>5.5 and centroids_list[i]<12):
            time_status_list.append("morning")
        if (centroids_list[i]>12 and centroids_list[i]<19):
            time_status_list.append("afternoon")
        if (centroids_list[i]>19 and centroids_list[i]<23.5):
            time_status_list.append("evening")
        if (centroids_list[i]>23.5 or 0<centroids_list[i]<5.5):
            time_status_list.append("early in the morning")
    
    time_status_list=list(set(time_status_list))
    user=data1['uname'][1]
    sentiments_status_total[user]=sentimentsstatus
    time_status_list_total[user]=time_status_list
    #词云部分
    text_total_str=','.join(content_list)   

    #text_total_str=text_total_str.decode('utf-8')
    song=SnowNLP(text_total_str)
    
    key=' '.join(song.keywords(35))
    font = r'C:\Windows\Fonts\simfang.ttf'
    my_wordcloud = WordCloud(font_path=font).generate(key)
    
    plt.imshow(my_wordcloud)
    fig_name=user+'.jpg'
    plt.axis('off')
    plt.savefig(fig_name)
    plt.show()
    
    
    bar.update() 
  
    
print(bar)  
 #将字典保存为csv文件(先转为DataFrame)
sentiments_all=pd.DataFrame.from_dict(sentiments_status_total,orient='index')
time_all=pd.DataFrame.from_dict(time_status_list_total,orient='index')
sentiments_all.to_csv('sentiments_all.txt')
time_all.to_csv('time_status_all.txt')

#用户群体分析——发帖时间直方图 
plt.figure("hist")
n, bins, patches = plt.hist(time_total, bins=24, normed=1,edgecolor='None',facecolor='red')  
plt.savefig("time_total.jpg")   
plt.show()
#用户群体分析——词云
text_total_str=','.join(content_list_total)   
song=SnowNLP(text_total_str)
key=' '.join(song.keywords(50))
font = r'C:\Windows\Fonts\simfang.ttf'
my_wordcloud = WordCloud(font_path=font).generate(key)
plt.imshow(my_wordcloud)
plt.axis('off')
plt.savefig("word_cloud_total_total.jpg")   
plt.show()
    
    