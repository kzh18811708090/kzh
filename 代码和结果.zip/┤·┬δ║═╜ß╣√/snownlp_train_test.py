# -*- coding: utf-8 -*-
"""
Created on Wed May  2 16:58:00 2018

@author: Administrator
"""
from snownlp import sentiment #加载情感分析模块


sentiment.train('E:/sentiments60000/neg60000_1.txt', 'E:/sentiments60000/pos60000_1.txt')
sentiment.save('D:/anaconda/Lib/site-packages/snownlp/sentiment/sentiment.marshal_2')#
#这一步是对上一步的训练结果进行保存,同时要把`snownlp/sentiment/__init__.py`里的`data_path`也改成你保存的位置，不然下次使用还是默认的。
